Lifemapper Client Library
========

The Lifemapper client library provides access to Lifemapper web services

Website: http://lifemapper.org

Author: CJ Grady 

Email: cjgrady@ku.edu

Version: 2.1.3

Purpose
========
   The Lifemapper client library is provided as a tool, written in Python, to
communicate with the Lifemapper web services. Additional web service
documentation can be found at: http://lifemapper.org/schemas/services.wadl

Dependencies
========
   Tested with Python 2.7
   
