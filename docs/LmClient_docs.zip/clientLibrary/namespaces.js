var namespaces =
[
    [ "core", "namespacecore.html", "namespacecore" ],
    [ "LmClient", "namespaceLmClient.html", "namespaceLmClient" ]
];