var NAVTREE =
[
  [ "Lifemapper Client Library", "index.html", [
    [ "Deprecated List", "deprecated.html", null ],
    [ "Packages", null, [
      [ "Packages", "namespaces.html", "namespaces" ],
      [ "Package Functions", "namespacemembers.html", [
        [ "All", "namespacemembers.html", "namespacemembers_dup" ],
        [ "Functions", "namespacemembers_func.html", null ],
        [ "Variables", "namespacemembers_vars.html", "namespacemembers_vars" ]
      ] ]
    ] ],
    [ "Classes", "annotated.html", [
      [ "Class List", "annotated.html", "annotated_dup" ],
      [ "Class Index", "classes.html", null ],
      [ "Class Hierarchy", "hierarchy.html", "hierarchy" ],
      [ "Class Members", "functions.html", [
        [ "All", "functions.html", "functions_dup" ],
        [ "Functions", "functions_func.html", "functions_func" ],
        [ "Variables", "functions_vars.html", "functions_vars" ]
      ] ]
    ] ],
    [ "Files", null, [
      [ "File List", "files.html", "files" ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"LmClient_2src_2LmClient_2____init_____8py.html",
"classcore_1_1LmCommon_1_1common_1_1apiquery_1_1APIQuery.html#a442deab8fee55657548f6d04cf812dab",
"classcore_1_1LmCommon_1_1common_1_1lmconstants_1_1JobStatus.html#a5fa27a63b1bce04755369e7e6d85cdba",
"classcore_1_1LmCommon_1_1tools_1_1testing_1_1testSuite_1_1LMTestSuite.html#aa86c3c2ec349bd0dc743f9580d79150a",
"lmconstants_8py.html#a31ed26b4b6889a3362179e9f11339c9f",
"unicode_8py.html#a8afe50a67983e8431bc1514ac866e397"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';