var classcore_1_1LmCommon_1_1common_1_1lmconstants_1_1InputDataType =
[
    [ "EDAC", "classcore_1_1LmCommon_1_1common_1_1lmconstants_1_1InputDataType.html#ada4287fd4d0d07784cd87e036bceea0a", null ],
    [ "LM_HIRES_CLIMATE", "classcore_1_1LmCommon_1_1common_1_1lmconstants_1_1InputDataType.html#ab3fdac263f8ae0a110ebb245018c6130", null ],
    [ "LM_LOWRES_CLIMATE", "classcore_1_1LmCommon_1_1common_1_1lmconstants_1_1InputDataType.html#afa818cf9423f0c44e7883695c50d2bb1", null ],
    [ "USER_ANCILLARY", "classcore_1_1LmCommon_1_1common_1_1lmconstants_1_1InputDataType.html#aab02cc888ca07be4fba1a337c6a35771", null ],
    [ "USER_PRESENCE_ABSENCE", "classcore_1_1LmCommon_1_1common_1_1lmconstants_1_1InputDataType.html#ab910a371db38e7d5845f05e48c4fdd80", null ]
];