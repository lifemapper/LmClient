var unicode_8py =
[
    [ "fromUnicode", "unicode_8py.html#affdf996252f9d87f0f5f5a69f688582f", null ],
    [ "toUnicode", "unicode_8py.html#a8afe50a67983e8431bc1514ac866e397", null ]
];