var searchData=
[
  ['parameteroutofrange',['ParameterOutOfRange',['../classLmClient_1_1sdm_1_1ParameterOutOfRange.html',1,'LmClient::sdm']]],
  ['projectionsnotallowed',['ProjectionsNotAllowed',['../classLmClient_1_1sdm_1_1ProjectionsNotAllowed.html',1,'LmClient::sdm']]]
];
