var searchData=
[
  ['unicode_2epy',['unicode.py',['../unicode_8py.html',1,'']]]
];
