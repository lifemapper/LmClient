var searchData=
[
  ['name',['name',['../classLmClient_1_1sdm_1_1AlgorithmParameter.html#aee7230fe68c392467c4e88b02b617cee',1,'LmClient.sdm.AlgorithmParameter.name()'],['../classLmClient_1_1sdm_1_1Algorithm.html#a41faefce0b0e30161a282fef15b5ff98',1,'LmClient.sdm.Algorithm.name()']]]
];
