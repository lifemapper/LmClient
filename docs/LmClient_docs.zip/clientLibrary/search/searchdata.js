var indexSectionsWithContent =
{
  0: "_abcdghilmnoprstuv",
  1: "_aloprs",
  2: "l",
  3: "_clors",
  4: "_acdghilmoprsv",
  5: "_abcdhilmnoprstuv",
  6: "d"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Pages"
};

