var singleton_8py =
[
    [ "singleton", "singleton_8py.html#a2a2ede5b0a733c6774b9029d78067f37", null ]
];