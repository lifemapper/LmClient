var localconstants_8py =
[
    [ "_CONFIG_HEADING", "db/d36/localconstants_8py.html#a85920cf670ab102f47fbfb7d371dc4cc", null ],
    [ "OTL_HINT_URL", "db/d36/localconstants_8py.html#a73e23757c11c54c2e83a4ca422a96585", null ],
    [ "OTL_TREE_WEB_URL", "db/d36/localconstants_8py.html#aa84e27f9ae1d2a84e8e2c96e30260bed", null ]
];