var searchData=
[
  ['name',['name',['../d2/dbd/classLmPython_1_1src_1_1sdm_1_1AlgorithmParameter.html#a3715e7f9f24e2df0a8ce8f831bd7ec4d',1,'LmPython.src.sdm.AlgorithmParameter.name()'],['../d5/d85/classLmPython_1_1src_1_1sdm_1_1Algorithm.html#a2e28ebc4fba6db3e846c47c22c472686',1,'LmPython.src.sdm.Algorithm.name()']]]
];
